#include "arrangement.h"
#include "ui_arrangement.h"

arrangement::arrangement(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::arrangement)
{
    ui->setupUi(this);
}

arrangement::~arrangement()
{
    delete ui;
}

void arrangement::on_arrange_clicked()
{
    /*
     *初始化参数
    */
    qDebug() << QString("点击排布");
    object1Num=0;
    object2Num=0;
    panelLength = (ui->panelLength->toPlainText()).toDouble();
    panelWidth = (ui->panelWidth->toPlainText()).toDouble();
    object1Num= (ui->object1_num->toPlainText()).toDouble();
    object2Num= (ui->object2_num->toPlainText()).toDouble();

    RS_Vector panelPoint1 = RS_Vector(0,panelWidth);
    RS_Vector panelPoint2 = RS_Vector(panelLength,panelWidth);
    RS_Vector panelPoint3 = RS_Vector(panelLength,0);

    qDebug() <<"初始化参数";

    /*
     *画板材边框
    */
    auto appWin=QC_ApplicationWindow::getAppWindow();
    RS_Document* d = appWin->getDocument();
    if (d) {
        RS_Graphic* graphic = (RS_Graphic*)d;
        if (!graphic) {
            return;
        }

        RS_Line* line1 = new RS_Line{graphic, RS_Vector(0,0), panelPoint1};
        RS_Line* line2 = new RS_Line{graphic, panelPoint1, panelPoint2};
        RS_Line* line3 = new RS_Line{graphic, panelPoint2, panelPoint3};
        RS_Line* line4 = new RS_Line{graphic, panelPoint3, RS_Vector(0,0)};

        line1->setPen(RS_Pen(RS_Color(255, 0, 0),
                                                RS2::Width15,
                                               RS2::SolidLine));
        line2->setPen(RS_Pen(RS_Color(255, 0, 0),
                                                RS2::Width15,
                                               RS2::SolidLine));
        line3->setPen(RS_Pen(RS_Color(255, 0, 0),
                                                RS2::Width15,
                                               RS2::SolidLine));
        line4->setPen(RS_Pen(RS_Color(255, 0, 0),
                                                RS2::Width15,
                                               RS2::SolidLine));

        graphic->addEntity(line1);
        graphic->addEntity(line2);
        graphic->addEntity(line3);
        graphic->addEntity(line4);

        EntityList = graphic->getEntityList();

//初始化PolylineList
        if(!EntityList.isEmpty())
        for(it_entity=EntityList.begin();it_entity!=EntityList.end(); it_entity++)
        {

             if( (*it_entity)->rtti()==RS2::EntityPolyline)
             {
                 if((*it_entity)->isVisible())
                 {
                     RS_Polyline *b=dynamic_cast<RS_Polyline*>(*it_entity);
                     //if(b->isClosed())
                     PolylineList.push_back(*b);
                 }

             }
        }
        qDebug() <<"初始化PolylineList";

//初始化TBA
        if(PolylineList.isEmpty())
            return;


        it_polyline = PolylineList.begin();

            for(int j=0;j<object1Num;j++)
            {
                TBA.push_back(ToBeArranged{(it_polyline)->getMax().x-(it_polyline)->getMin().x,(it_polyline)->getMax().y-(it_polyline)->getMin().y,new RS_Polyline});
                TBA.last().polyline = *(dynamic_cast<RS_Polyline*>(it_polyline->clone()));

            }



            it_polyline++;

            for(int j=0;j<object2Num;j++)
            {
                TBA.push_back(ToBeArranged{(it_polyline)->getMax().x-(it_polyline)->getMin().x,(it_polyline)->getMax().y-(it_polyline)->getMin().y,new RS_Polyline});
                TBA.last().polyline = *(dynamic_cast<RS_Polyline*>(it_polyline->clone()));
            }
        qDebug() <<"初始化TBA";

        //调用排布函数
        arrange(graphic);
        qDebug() <<"排布完成";

    }

    RS_GraphicView* v = appWin->getGraphicView();
    if (v) {
        v->redraw();}


}

/*
 *排布函数
*/
void arrangement::arrange(RS_Graphic* graphic){
    double coordinateIndexX=0,coordinateIndexY=0,subY=0;
    maxWidth=0;
    for(it=TBA.begin();it!=TBA.end();it++)
    {
        if(coordinateIndexX+it->length<=panelLength&&coordinateIndexY+it->width<=panelWidth)
        {
            (*it).polyline.move(RS_Vector(coordinateIndexX-(*it).polyline.getMin().x,coordinateIndexY-(*it).polyline.getMin().y));
            object.push_back(&((*it).polyline));
            object.back()->setLayerToActive();
            object.back()->setPenToActive();


            coordinateIndexX+=it->length;
            graphic->addEntity( object.back());
            if(it->width>maxWidth)  maxWidth=it->width;
            qDebug() <<"向右排列";
            if(it!=(TBA.end()-1))
            {
                subY=coordinateIndexY+(it)->width;
                while(subY+(it+1)->width<=maxWidth)
                {
                    it++;
                    (*it).polyline.move(RS_Vector(coordinateIndexX-(*it).polyline.getMin().x,subY-(*it).polyline.getMin().y));
                    object.push_back(&((*it).polyline));
                    object.back()->setLayerToActive();
                    object.back()->setPenToActive();
                    subY+=(it->width);
                    graphic->addEntity( object.back());
                    qDebug() <<"叠一层";
                }

            }


        }

       else if(coordinateIndexY+it->width+maxWidth<=panelWidth)
        {
            coordinateIndexX=0;
            coordinateIndexY+=maxWidth;

            (*it).polyline.move(RS_Vector(coordinateIndexX-(*it).polyline.getMin().x,coordinateIndexY-(*it).polyline.getMin().y));
            object.push_back(&((*it).polyline));
            object.back()->setLayerToActive();
            object.back()->setPenToActive();
            coordinateIndexX+=it->length;
            graphic->addEntity( object.back());
            maxWidth=it->width;

        }
    }



}

void arrangement::on_clear_clicked()
{
    auto appWin=QC_ApplicationWindow::getAppWindow();
    RS_Document* d = appWin->getDocument();
    RS_Graphic* graphic = (RS_Graphic*)d;
    graphic->clear();
    RS_GraphicView* v = appWin->getGraphicView();
    v->redraw();
    TBA.clear();
    EntityList.clear();
    PolylineList.clear();




}
